package com.cg.neel.igrs.district.fileid.repository;


import org.springframework.stereotype.Repository;

import com.cg.neel.igrs.district.fileid.BemetaraFileIdAccessBean;


@Repository
public interface BemetaraFileIdRepository extends MappedTypeFileIdRepository<BemetaraFileIdAccessBean>{

}
