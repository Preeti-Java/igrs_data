package com.cg.neel.igrs.district.fileid;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.cg.neel.igrs.district.BastarDeedAccessBean;
import com.cg.neel.igrs.district.BastarParty1AccessBean;
import com.cg.neel.igrs.district.BastarParty2AccessBean;
import com.cg.neel.igrs.district.BastarPropertyAccessBean;

@Entity
@Table(name = "Bastar_FileId")
public class BastarFileIdAccessBean {
	
	@Id
	@Column(name = "Sno")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long sno;
	
	@OneToOne
	@JoinColumn(name="BastarDeed_Fileid")
	private BastarDeedAccessBean BastarDeedAccessBean;
	
	@OneToOne
	@JoinColumn(name="BastarParty1_Fileid")
	private BastarParty1AccessBean BastarParty1AccessBean;
	
	@OneToOne
	@JoinColumn(name="BastarParty2_Fileid")
	private BastarParty2AccessBean BastarParty2AccessBean;
	
	@OneToOne
	@JoinColumn(name="BastarProperty_Fileid")
	private BastarPropertyAccessBean BastarPropertyAccessBean;
	
	
	

}
