package com.cg.neel.igrs.district.fileid;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.cg.neel.igrs.district.BilaspurDeedAccessBean;
import com.cg.neel.igrs.district.BilaspurParty1AccessBean;
import com.cg.neel.igrs.district.BilaspurParty2AccessBean;
import com.cg.neel.igrs.district.BilaspurPropertyAccessBean;

@Entity
@Table(name = "Bilaspur_FileId")
public class BilaspurFileIdAccessBean {
	
	@Id
	@Column(name = "Sno")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long sno;
	
	@OneToOne
	@JoinColumn(name="BilaspurDeed_Fileid")
	private BilaspurDeedAccessBean BilaspurDeedAccessBean;
	
	@OneToOne
	@JoinColumn(name="BilaspurParty1_Fileid")
	private BilaspurParty1AccessBean BilaspurParty1AccessBean;
	
	@OneToOne
	@JoinColumn(name="BilaspurParty2_Fileid")
	private BilaspurParty2AccessBean BilaspurParty2AccessBean;
	
	@OneToOne
	@JoinColumn(name="BilaspurProperty_Fileid")
	private BilaspurPropertyAccessBean BilaspurPropertyAccessBean;
	
	
	

}
