/**
 * 
 */
package com.cg.neel.igrs.district;

import javax.persistence.Entity;
import javax.persistence.Table;

import com.cg.neel.igrs.district.common.CommonPropertyAccessBean;

/**
 * @author 
 * @Des Balod Property details
 *
 */

@Entity
@Table(name ="BalodProperty")
public class BalodPropertyAccessBean extends CommonPropertyAccessBean{

}
