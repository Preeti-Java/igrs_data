package com.cg.neel.igrs.district.fileid;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.cg.neel.igrs.district.DantewadaDeedAccessBean;
import com.cg.neel.igrs.district.DantewadaParty1AccessBean;
import com.cg.neel.igrs.district.DantewadaParty2AccessBean;
import com.cg.neel.igrs.district.DantewadaPropertyAccessBean;

@Entity
@Table(name = "Dantewada_FileId")
public class DantewadaFileIdAccessBean {
	
	@Id
	@Column(name = "Sno")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long sno;
	
	@OneToOne
	@JoinColumn(name="DantewadaDeed_Fileid")
	private DantewadaDeedAccessBean DantewadaDeedAccessBean;
	
	@OneToOne
	@JoinColumn(name="DantewadaParty1_Fileid")
	private DantewadaParty1AccessBean DantewadaParty1AccessBean;
	
	@OneToOne
	@JoinColumn(name="DantewadaParty2_Fileid")
	private DantewadaParty2AccessBean DantewadaParty2AccessBean;
	
	@OneToOne
	@JoinColumn(name="DantewadaProperty_Fileid")
	private DantewadaPropertyAccessBean DantewadaPropertyAccessBean;
	
	
	

}
