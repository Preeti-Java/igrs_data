package com.cg.neel.igrs.district.fileid.repository;


import org.springframework.stereotype.Repository;

import com.cg.neel.igrs.district.fileid.BalodFileIdAccessBean;

@Repository
public interface BalodFileIdRepository extends MappedTypeFileIdRepository<BalodFileIdAccessBean>{

}
