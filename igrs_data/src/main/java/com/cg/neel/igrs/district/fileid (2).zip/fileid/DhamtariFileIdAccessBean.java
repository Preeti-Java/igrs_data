package com.cg.neel.igrs.district.fileid;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.cg.neel.igrs.district.DhamtariDeedAccessBean;
import com.cg.neel.igrs.district.DhamtariParty1AccessBean;
import com.cg.neel.igrs.district.DhamtariParty2AccessBean;
import com.cg.neel.igrs.district.DhamtariPropertyAccessBean;

@Entity
@Table(name = "Dhamtari_FileId")
public class DhamtariFileIdAccessBean {
	
	@Id
	@Column(name = "Sno")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long sno;
	
	@OneToOne
	@JoinColumn(name="DhamtariDeed_Fileid")
	private DhamtariDeedAccessBean DhamtariDeedAccessBean;
	
	@OneToOne
	@JoinColumn(name="DhamtariParty1_Fileid")
	private DhamtariParty1AccessBean DhamtariParty1AccessBean;
	
	@OneToOne
	@JoinColumn(name="DhamtariParty2_Fileid")
	private DhamtariParty2AccessBean DhamtariParty2AccessBean;
	
	@OneToOne
	@JoinColumn(name="DhamtariProperty_Fileid")
	private DhamtariPropertyAccessBean DhamtariPropertyAccessBean;
	
	
	

}
