package com.cg.neel.igrs.district.fileid;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.cg.neel.igrs.district.SargujaDeedAccessBean;
import com.cg.neel.igrs.district.SargujaParty1AccessBean;
import com.cg.neel.igrs.district.SargujaParty2AccessBean;
import com.cg.neel.igrs.district.SargujaPropertyAccessBean;

@Entity
@Table(name = "Sarguja_FileId")
public class SargujaFileIdAccessBean {
	
	@Id
	@Column(name = "Sno")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long sno;
	
	@OneToOne
	@JoinColumn(name="SargujaDeed_Fileid")
	private SargujaDeedAccessBean SargujaDeedAccessBean;
	
	@OneToOne
	@JoinColumn(name="SargujaParty1_Fileid")
	private SargujaParty1AccessBean SargujaParty1AccessBean;
	
	@OneToOne
	@JoinColumn(name="SargujaParty2_Fileid")
	private SargujaParty2AccessBean SargujaParty2AccessBean;
	
	@OneToOne
	@JoinColumn(name="SargujaProperty_Fileid")
	private SargujaPropertyAccessBean SargujaPropertyAccessBean;
	
	
	

}
