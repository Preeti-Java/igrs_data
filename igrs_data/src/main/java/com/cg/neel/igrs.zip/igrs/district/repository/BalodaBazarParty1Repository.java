/**
 * 
 */
package com.cg.neel.igrs.district.repository;

import org.springframework.stereotype.Repository;

import com.cg.neel.igrs.district.BalodaBazarParty1AccessBean;
import com.cg.neel.igrs.district.help.repository.MappedTypeParty1Repository;


/**
 * @author User
 *
 */
@Repository
public interface BalodaBazarParty1Repository extends MappedTypeParty1Repository<BalodaBazarParty1AccessBean>{

}
