package com.cg.neel.igrs.district.fileid.repository;


import org.springframework.stereotype.Repository;

import com.cg.neel.igrs.district.fileid.RaigarhFileIdAccessBean;

@Repository
public interface RaigarhFileIdRepository extends MappedTypeFileIdRepository<RaigarhFileIdAccessBean>{

}
