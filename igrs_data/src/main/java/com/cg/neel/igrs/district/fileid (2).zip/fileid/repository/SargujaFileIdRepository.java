package com.cg.neel.igrs.district.fileid.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.neel.igrs.district.fileid.SargujaFileIdAccessBean;

@Repository
public interface SargujaFileIdRepository extends JpaRepository<SargujaFileIdAccessBean,Long>{

}
