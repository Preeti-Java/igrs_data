package com.cg.neel.igrs.district.fileid;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.cg.neel.igrs.district.KankerDeedAccessBean;
import com.cg.neel.igrs.district.KankerParty1AccessBean;
import com.cg.neel.igrs.district.KankerParty2AccessBean;
import com.cg.neel.igrs.district.KankerPropertyAccessBean;

@Entity
@Table(name = "Kanker_FileId")
public class KankerFileIdAccessBean {
	
	@Id
	@Column(name = "Sno")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long sno;
	
	@OneToOne
	@JoinColumn(name="KankerDeed_Fileid")
	private KankerDeedAccessBean KankerDeedAccessBean;
	
	@OneToOne
	@JoinColumn(name="KankerParty1_Fileid")
	private KankerParty1AccessBean KankerParty1AccessBean;
	
	@OneToOne
	@JoinColumn(name="KankerParty2_Fileid")
	private KankerParty2AccessBean KankerParty2AccessBean;
	
	@OneToOne
	@JoinColumn(name="KankerProperty_Fileid")
	private KankerPropertyAccessBean KankerPropertyAccessBean;
	
	
	

}
