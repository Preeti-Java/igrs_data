package com.cg.neel.igrs.district.fileid;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.cg.neel.igrs.district.RajnandgaonDeedAccessBean;
import com.cg.neel.igrs.district.RajnandgaonParty1AccessBean;
import com.cg.neel.igrs.district.RajnandgaonParty2AccessBean;
import com.cg.neel.igrs.district.RajnandgaonPropertyAccessBean;

@Entity
@Table(name = "Rajnandgaon_FileId")
public class RajnandgaonFileIdAccessBean {
	
	@Id
	@Column(name = "Sno")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long sno;
	
	@OneToOne
	@JoinColumn(name="RajnandgaonDeed_Fileid")
	private RajnandgaonDeedAccessBean RajnandgaonDeedAccessBean;
	
	@OneToOne
	@JoinColumn(name="RajnandgaonParty1_Fileid")
	private RajnandgaonParty1AccessBean RajnandgaonParty1AccessBean;
	
	@OneToOne
	@JoinColumn(name="RajnandgaonParty2_Fileid")
	private RajnandgaonParty2AccessBean RajnandgaonParty2AccessBean;
	
	@OneToOne
	@JoinColumn(name="RajnandgaonRajnandgaon_Fileid")
	private RajnandgaonPropertyAccessBean RajnandgaonPropertyAccessBean;
	
	
	

}
