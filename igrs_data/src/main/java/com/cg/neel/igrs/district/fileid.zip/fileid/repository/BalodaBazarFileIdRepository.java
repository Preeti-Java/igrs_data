package com.cg.neel.igrs.district.fileid.repository;


import org.springframework.stereotype.Repository;

import com.cg.neel.igrs.district.fileid.BalodaBazarFileIdAccessBean;

@Repository
public interface BalodaBazarFileIdRepository extends MappedTypeFileIdRepository<BalodaBazarFileIdAccessBean>{


}
