package com.cg.neel.igrs.district.fileid;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.cg.neel.igrs.district.MungeliDeedAccessBean;
import com.cg.neel.igrs.district.MungeliParty1AccessBean;
import com.cg.neel.igrs.district.MungeliParty2AccessBean;
import com.cg.neel.igrs.district.MungeliPropertyAccessBean;

@Entity
@Table(name = "Mungeli_FileId")
public class MungeliFileIdAccessBean {
	
	@Id
	@Column(name = "Sno")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long sno;
	
	@OneToOne
	@JoinColumn(name="MungeliDeed_Fileid")
	private MungeliDeedAccessBean MungeliDeedAccessBean;
	
	@OneToOne
	@JoinColumn(name="MungeliParty1_Fileid")
	private MungeliParty1AccessBean MungeliParty1AccessBean;
	
	@OneToOne
	@JoinColumn(name="MungeliParty2_Fileid")
	private MungeliParty2AccessBean MungeliParty2AccessBean;
	
	@OneToOne
	@JoinColumn(name="MungeliProperty_Fileid")
	private MungeliPropertyAccessBean MungeliPropertyAccessBean;
	
	
	

}
