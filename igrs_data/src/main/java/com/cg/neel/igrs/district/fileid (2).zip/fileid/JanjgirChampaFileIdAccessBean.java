package com.cg.neel.igrs.district.fileid;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.cg.neel.igrs.district.JanjgirChampaDeedAccessBean;
import com.cg.neel.igrs.district.JanjgirChampaParty1AccessBean;
import com.cg.neel.igrs.district.JanjgirChampaParty2AccessBean;
import com.cg.neel.igrs.district.JanjgirChampaPropertyAccessBean;

@Entity
@Table(name = "JanjgirChampa_FileId")
public class JanjgirChampaFileIdAccessBean {
	
	@Id
	@Column(name = "Sno")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long sno;
	
	@OneToOne
	@JoinColumn(name="JanjgirChampaDeed_Fileid")
	private JanjgirChampaDeedAccessBean JanjgirChampaDeedAccessBean;
	
	@OneToOne
	@JoinColumn(name="JanjgirChampaParty1_Fileid")
	private JanjgirChampaParty1AccessBean JanjgirChampaParty1AccessBean;
	
	@OneToOne
	@JoinColumn(name="JanjgirChampaParty2_Fileid")
	private JanjgirChampaParty2AccessBean JanjgirChampaParty2AccessBean;
	
	@OneToOne
	@JoinColumn(name="JanjgirChampaProperty_Fileid")
	private JanjgirChampaPropertyAccessBean JanjgirChampaPropertyAccessBean;
	
	
	

}
