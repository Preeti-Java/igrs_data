package com.cg.neel.igrs.district.fileid;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.cg.neel.igrs.district.KawardhaDeedAccessBean;
import com.cg.neel.igrs.district.KawardhaParty1AccessBean;
import com.cg.neel.igrs.district.KawardhaParty2AccessBean;
import com.cg.neel.igrs.district.KawardhaPropertyAccessBean;

@Entity
@Table(name = "Kawardha_FileId")
public class KawardhaFileIdAccessBean {
	
	@Id
	@Column(name = "Sno")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long sno;
	
	@OneToOne
	@JoinColumn(name="KawardhaDeed_Fileid")
	private KawardhaDeedAccessBean KawardhaDeedAccessBean;
	
	@OneToOne
	@JoinColumn(name="KawardhaParty1_Fileid")
	private KawardhaParty1AccessBean KawardhaParty1AccessBean;
	
	@OneToOne
	@JoinColumn(name="KawardhaParty2_Fileid")
	private KawardhaParty2AccessBean KawardhaParty2AccessBean;
	
	@OneToOne
	@JoinColumn(name="KawardhaProperty_Fileid")
	private KawardhaPropertyAccessBean KawardhaPropertyAccessBean;
	
	
	

}
