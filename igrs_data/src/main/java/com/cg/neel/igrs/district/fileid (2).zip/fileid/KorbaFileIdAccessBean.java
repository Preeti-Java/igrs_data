package com.cg.neel.igrs.district.fileid;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.cg.neel.igrs.district.KorbaDeedAccessBean;
import com.cg.neel.igrs.district.KorbaParty1AccessBean;
import com.cg.neel.igrs.district.KorbaParty2AccessBean;
import com.cg.neel.igrs.district.KorbaPropertyAccessBean;

@Entity
@Table(name = "Korba_FileId")
public class KorbaFileIdAccessBean {
	
	@Id
	@Column(name = "Sno")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long sno;
	
	@OneToOne
	@JoinColumn(name="KorbaDeed_Fileid")
	private KorbaDeedAccessBean KorbaDeedAccessBean;
	
	@OneToOne
	@JoinColumn(name="KorbaParty1_Fileid")
	private KorbaParty1AccessBean KorbaParty1AccessBean;
	
	@OneToOne
	@JoinColumn(name="KorbaParty2_Fileid")
	private KorbaParty2AccessBean KorbaParty2AccessBean;
	
	@OneToOne
	@JoinColumn(name="KorbaProperty_Fileid")
	private KorbaPropertyAccessBean KorbaPropertyAccessBean;
	
	
	

}
