package com.cg.neel.igrs.district.fileid;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.cg.neel.igrs.district.MahasamundDeedAccessBean;
import com.cg.neel.igrs.district.MahasamundParty1AccessBean;
import com.cg.neel.igrs.district.MahasamundParty2AccessBean;
import com.cg.neel.igrs.district.MahasamundPropertyAccessBean;

@Entity
@Table(name = "Mahasamund_FileId")
public class MahasamundFileIdAccessBean {
	
	@Id
	@Column(name = "Sno")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long sno;
	
	@OneToOne
	@JoinColumn(name="MahasamundDeed_Fileid")
	private MahasamundDeedAccessBean MahasamundDeedAccessBean;
	
	@OneToOne
	@JoinColumn(name="MahasamundParty1_Fileid")
	private MahasamundParty1AccessBean MahasamundParty1AccessBean;
	
	@OneToOne
	@JoinColumn(name="MahasamundParty2_Fileid")
	private MahasamundParty2AccessBean MahasamundParty2AccessBean;
	
	@OneToOne
	@JoinColumn(name="MahasamundProperty_Fileid")
	private MahasamundPropertyAccessBean MahasamundPropertyAccessBean;
	
	
	

}
