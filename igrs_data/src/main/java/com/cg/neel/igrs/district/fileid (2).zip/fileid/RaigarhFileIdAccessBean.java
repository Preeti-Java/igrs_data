package com.cg.neel.igrs.district.fileid;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.cg.neel.igrs.district.RaigarhDeedAccessBean;
import com.cg.neel.igrs.district.RaigarhParty1AccessBean;
import com.cg.neel.igrs.district.RaigarhParty2AccessBean;
import com.cg.neel.igrs.district.RaigarhPropertyAccessBean;

@Entity
@Table(name = "Raigarh_FileId")
public class RaigarhFileIdAccessBean {
	
	@Id
	@Column(name = "Sno")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long sno;
	
	@OneToOne
	@JoinColumn(name="RaigarhDeed_Fileid")
	private RaigarhDeedAccessBean RaigarhDeedAccessBean;
	
	@OneToOne
	@JoinColumn(name="RaigarhParty1_Fileid")
	private RaigarhParty1AccessBean RaigarhParty1AccessBean;
	
	@OneToOne
	@JoinColumn(name="RaigarhParty2_Fileid")
	private RaigarhParty2AccessBean RaigarhParty2AccessBean;
	
	@OneToOne
	@JoinColumn(name="RaigarhProperty_Fileid")
	private RaigarhPropertyAccessBean RaigarhPropertyAccessBean;
	
	
	

}
