package com.cg.neel.igrs.district.fileid.repository;


import org.springframework.stereotype.Repository;

import com.cg.neel.igrs.district.fileid.DhamtariFileIdAccessBean;


@Repository
public interface DhamtariFileIdRepository extends MappedTypeFileIdRepository<DhamtariFileIdAccessBean>{

}
