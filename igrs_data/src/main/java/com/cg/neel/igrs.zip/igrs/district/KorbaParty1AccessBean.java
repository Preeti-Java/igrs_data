package com.cg.neel.igrs.district;

import javax.persistence.Entity;
import javax.persistence.Table;

import com.cg.neel.igrs.district.common.CommonParty1DetailsAccessBean;

@Entity
@Table(name = "KorbaParty1")
public class KorbaParty1AccessBean extends CommonParty1DetailsAccessBean{

}
