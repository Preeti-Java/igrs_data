package com.cg.neel.igrs.district.fileid;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.cg.neel.igrs.district.RaipurDeedAccessBean;
import com.cg.neel.igrs.district.RaipurParty1AccessBean;
import com.cg.neel.igrs.district.RaipurParty2AccessBean;
import com.cg.neel.igrs.district.RaipurPropertyAccessBean;

@Entity
@Table(name = "Raipur_FileId")
public class RaipurFileIdAccessBean {
	
	@Id
	@Column(name = "Sno")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long sno;
	
	@OneToOne
	@JoinColumn(name="RaipurDeed_Fileid")
	private RaipurDeedAccessBean RaipurDeedAccessBean;
	
	@OneToOne
	@JoinColumn(name="RaipurParty1_Fileid")
	private RaipurParty1AccessBean RaipurParty1AccessBean;
	
	@OneToOne
	@JoinColumn(name="RaipurParty2_Fileid")
	private RaipurParty2AccessBean RaipurParty2AccessBean;
	
	@OneToOne
	@JoinColumn(name="RaipurProperty_Fileid")
	private RaipurPropertyAccessBean RaipurPropertyAccessBean;
	
	
	

}
