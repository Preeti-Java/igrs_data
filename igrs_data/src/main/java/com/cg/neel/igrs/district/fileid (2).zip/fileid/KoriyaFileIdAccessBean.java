package com.cg.neel.igrs.district.fileid;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.cg.neel.igrs.district.KoriyaDeedAccessBean;
import com.cg.neel.igrs.district.KoriyaParty1AccessBean;
import com.cg.neel.igrs.district.KoriyaParty2AccessBean;
import com.cg.neel.igrs.district.KoriyaPropertyAccessBean;

@Entity
@Table(name = "Koriya_FileId")
public class KoriyaFileIdAccessBean {
	
	@Id
	@Column(name = "Sno")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long sno;
	
	@OneToOne
	@JoinColumn(name="KoriyaDeed_Fileid")
	private KoriyaDeedAccessBean KoriyaDeedAccessBean;
	
	@OneToOne
	@JoinColumn(name="KoriyaParty1_Fileid")
	private KoriyaParty1AccessBean KoriyaParty1AccessBean;
	
	@OneToOne
	@JoinColumn(name="KoriyaParty2_Fileid")
	private KoriyaParty2AccessBean KoriyaParty2AccessBean;
	
	@OneToOne
	@JoinColumn(name="KoriyaProperty_Fileid")
	private KoriyaPropertyAccessBean KoriyaPropertyAccessBean;
	
	
	

}
