package com.cg.neel.igrs.district.fileid;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.cg.neel.igrs.district.JashpurDeedAccessBean;
import com.cg.neel.igrs.district.JashpurParty1AccessBean;
import com.cg.neel.igrs.district.JashpurParty2AccessBean;
import com.cg.neel.igrs.district.JashpurPropertyAccessBean;

@Entity
@Table(name = "Jashpur_FileId")
public class JashpurFileIdAccessBean {
	
	@Id
	@Column(name = "Sno")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long sno;
	
	@OneToOne
	@JoinColumn(name="JashpurDeed_Fileid")
	private JashpurDeedAccessBean JashpurDeedAccessBean;
	
	@OneToOne
	@JoinColumn(name="JashpurParty1_Fileid")
	private JashpurParty1AccessBean JashpurParty1AccessBean;
	
	@OneToOne
	@JoinColumn(name="JashpurParty2_Fileid")
	private JashpurParty2AccessBean JashpurParty2AccessBean;
	
	@OneToOne
	@JoinColumn(name="JashpurProperty_Fileid")
	private JashpurPropertyAccessBean JashpurPropertyAccessBean;
	
	
	

}
