package com.cg.neel.igrs.district.fileid;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.cg.neel.igrs.district.BemetaraDeedAccessBean;
import com.cg.neel.igrs.district.BemetaraParty1AccessBean;
import com.cg.neel.igrs.district.BemetaraParty2AccessBean;
import com.cg.neel.igrs.district.BemetaraPropertyAccessBean;

@Entity
@Table(name = "Bemetara_FileId")
public class BemetaraFileIdAccessBean {
	
	@Id
	@Column(name = "Sno")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long sno;
	
	@OneToOne
	@JoinColumn(name="BemetaraDeed_Fileid")
	private BemetaraDeedAccessBean BemetaraDeedAccessBean;
	
	@OneToOne
	@JoinColumn(name="BemetaraParty1_Fileid")
	private BemetaraParty1AccessBean BemetaraParty1AccessBean;
	
	@OneToOne
	@JoinColumn(name="BemetaraParty2_Fileid")
	private BemetaraParty2AccessBean BemetaraParty2AccessBean;
	
	@OneToOne
	@JoinColumn(name="BemetaraProperty_Fileid")
	private BemetaraPropertyAccessBean BemetaraPropertyAccessBean;
	
	
	

}
