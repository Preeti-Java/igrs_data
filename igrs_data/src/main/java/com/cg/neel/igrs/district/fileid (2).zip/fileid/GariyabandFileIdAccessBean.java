package com.cg.neel.igrs.district.fileid;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.cg.neel.igrs.district.GariyabandDeedAccessBean;
import com.cg.neel.igrs.district.GariyabandParty1AccessBean;
import com.cg.neel.igrs.district.GariyabandParty2AccessBean;
import com.cg.neel.igrs.district.GariyabandPropertyAccessBean;

@Entity
@Table(name = "Gariyaband_FileId")
public class GariyabandFileIdAccessBean {
	
	@Id
	@Column(name = "Sno")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long sno;
	
	@OneToOne
	@JoinColumn(name="GariyabandDeed_Fileid")
	private GariyabandDeedAccessBean GariyabandDeedAccessBean;
	
	@OneToOne
	@JoinColumn(name="GariyabandParty1_Fileid")
	private GariyabandParty1AccessBean GariyabandParty1AccessBean;
	
	@OneToOne
	@JoinColumn(name="GariyabandParty2_Fileid")
	private GariyabandParty2AccessBean GariyabandParty2AccessBean;
	
	@OneToOne
	@JoinColumn(name="GariyabandProperty_Fileid")
	private GariyabandPropertyAccessBean GariyabandPropertyAccessBean;
	
	
	

}
