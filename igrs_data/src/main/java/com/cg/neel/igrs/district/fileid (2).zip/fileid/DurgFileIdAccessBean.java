package com.cg.neel.igrs.district.fileid;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.cg.neel.igrs.district.DurgDeedAccessBean;
import com.cg.neel.igrs.district.DurgParty1AccessBean;
import com.cg.neel.igrs.district.DurgParty2AccessBean;
import com.cg.neel.igrs.district.DurgPropertyAccessBean;

@Entity
@Table(name = "Durg_FileId")
public class DurgFileIdAccessBean {
	
	@Id
	@Column(name = "Sno")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long sno;
	
	@OneToOne
	@JoinColumn(name="DurgDeed_Fileid")
	private DurgDeedAccessBean DurgDeedAccessBean;
	
	@OneToOne
	@JoinColumn(name="DurgParty1_Fileid")
	private DurgParty1AccessBean DurgParty1AccessBean;
	
	@OneToOne
	@JoinColumn(name="DurgParty2_Fileid")
	private DurgParty2AccessBean DurgParty2AccessBean;
	
	@OneToOne
	@JoinColumn(name="DurgProperty_Fileid")
	private DurgPropertyAccessBean DurgPropertyAccessBean;
	
	
	

}
